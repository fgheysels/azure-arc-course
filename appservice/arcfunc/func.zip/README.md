# Create ZIP archive

zip -r func.zip .